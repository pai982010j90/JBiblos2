/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista.Nivel2;

/**
 *
 * @author nanohp
 * Preparando cambio en los modos de ventana para empezar a tratarlos como enum
 * y no como String
 */
public enum ModosVentana {

    ALTA,
    BAJA,
    CONSULTA,
    MODIFICACION;
}
