/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Vista.Varios;

import javax.swing.plaf.ColorUIResource;
import javax.swing.plaf.FontUIResource;
import javax.swing.plaf.metal.MetalTheme;

/**
 *
 * @author nanohp
 */
public class TestTheme extends MetalTheme {

    public TestTheme() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public String getName() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected ColorUIResource getPrimary1() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected ColorUIResource getPrimary2() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected ColorUIResource getPrimary3() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected ColorUIResource getSecondary1() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected ColorUIResource getSecondary2() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    protected ColorUIResource getSecondary3() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public FontUIResource getControlTextFont() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public FontUIResource getSystemTextFont() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public FontUIResource getUserTextFont() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public FontUIResource getMenuTextFont() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public FontUIResource getWindowTitleFont() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public FontUIResource getSubTextFont() {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
