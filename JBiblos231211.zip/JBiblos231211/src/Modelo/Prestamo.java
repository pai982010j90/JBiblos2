package Modelo;

import java.util.Date;

public class Prestamo {

	private Date fPrestamo;
	private Date fDevPropuesta;
	private Date FDevReal;
}