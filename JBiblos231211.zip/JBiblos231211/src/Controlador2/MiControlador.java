/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Controlador2;

/**
 *
 * @author nanohp
 */
public class MiControlador extends AbstractController {

    public static final String ELEMENT_TEXT_PROPERTY = "Texto";

    public void changeElementText(String newText) {
        setModelProperty(ELEMENT_TEXT_PROPERTY, newText);
    }
}
